import numpy as np

def preprocess():
	data = pd.read_csv('weatherAUS.csv')

	# Drop certain features any any data with null values
	data = data.drop(['Sunshine','Evaporation','Cloud3pm','Cloud9am','Location','RISK_MM','Date'],axis=1)
	data = data.dropna(how='any')

	# Change labels
	data['RainToday'].replace({'No': 0, 'Yes': 1},inplace = True)
	data['RainTomorrow'].replace({'No': 0, 'Yes': 1},inplace = True)

	# Change categorical data to integers
	categorical_columns = ['WindGustDir', 'WindDir3pm', 'WindDir9am']
	data = pd.get_dummies(data, columns=categorical_columns)

	# standardize data set
	scaler = preprocessing.MinMaxScaler()
	scaler.fit(data)
	data = pd.DataFrame(scaler.transform(data), index=data.index, columns=data.columns)

	y = data.pop('RainTomorrow')
	X_train, X_test, y_train, y_test = train_test_split(data, y, test_size=0.2)
	return X_train, X_test, y_train, y_test

class LogisticRegression(object):

    def __init__(self):
		self.X_train, X_test, self.y_train, y_test = preprocess()

    def evaluate(self, X_test, y_test):
    	"""Returns a numpy array of prediction labels"""
        pass