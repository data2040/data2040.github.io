import matplotlib.pyplot as plt
import numpy as np
import scipy
import cvxpy as cp
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
import pandas as pd


def preprocess():
    data = pd.read_csv('weatherAUS.csv')

    # Drop certain features any any data with null values
    data = data.drop(['Sunshine','Evaporation','Cloud3pm','Cloud9am','Location','RISK_MM','Date'],axis=1)
    data = data.dropna(how='any')

    # Change labels
    data['RainToday'].replace({'No': 0, 'Yes': 1},inplace = True)
    data['RainTomorrow'].replace({'No': -1, 'Yes': 1},inplace = True)

    # Change categorical data to integers
    categorical_columns = ['WindGustDir', 'WindDir3pm', 'WindDir9am']
    data = pd.get_dummies(data, columns=categorical_columns)

    # standardize data set
    scaler = preprocessing.MinMaxScaler()
    scaler.fit(data)
    data = pd.DataFrame(scaler.transform(data), index=data.index, columns=data.columns)

    y = data.pop('RainTomorrow')
    X_train, X_test, y_train, y_test = train_test_split(data, y, test_size=0.2)
    return X_train, X_test, y_train, y_test


class LinearSVM(object):
    """A support vector machine with linear kernel that trains using 
       the primal convex minimization problem"""
    
    def __init__(self, C=1.0):
        self.C = C
        self.w = None
        self.b = None
    
    def train(self, X, Y):
        """Use training arrays to set the values of self.w and self.b"""
        if isinstance(X, pd.DataFrame):
            X = X.values
        if isinstance(X, pd.DataFrame): 
            Y = Y.values
        nrows, ncols = np.shape(X)
        ζ = cp.Variable(nrows)
        w = cp.Variable() # insert the correct length for w 
        b = cp.Variable()
        objective = # use cp.sum_squares and cp.sum to form the objective function
        constraints = # apply the optimization constraints (hint: cp.multiply)
        prob = cp.Problem(objective, constraints)
        prob.solve()
        self.w = w.value
        self.b = b.value

    def predict(self, X_test):
        """Return a numpy array of prediction labels"""
        pass


def linear_kernel(a,b):
    pass

def polynomial_kernel(a,b):
    pass

def rbf_kernel(a,b):
    pass    

class SVM(object):
    def __init__(self, kernel=rbf_kernel, C=1.0):
        self.kernel = kernel
        self.C = C
        self.w = None
        self.α = None
        self.b = None

    def train(self, X, Y):
        """Use training arrays X and Y to set the values of self.α and self.b"""
        if isinstance(X, pd.DataFrame):
            X = X.values
        if isinstance(X, pd.DataFrame): 
            Y = Y.values
        nrows, ncols = np.shape(X)
        α = cp.Variable(nrows)
        w = cp.Variable(ncols)
        K = # form a kernel matrix (as a numpy array)
        objective = cp.Minimize(1/2 * cp.quad_form(cp.multiply(α,Y), K)
                                    - cp.sum(α))
        constraints = # list the constraints for the optimization problem
        prob = cp.Problem(objective, constraints)
        prob.solve()
        self.α = # fill in the value of α
        self.b = # fill in the value of b

    def predict(self, X_test):
        """Return a numpy array of prediction labels"""
        pass
